package PatternPrinting;

import java.util.Scanner;

public class RhombusPattern {
    public static void main(String[] args) {
        Scanner obj1 = new Scanner(System.in);
        System.out.print("Please enter the no. of rows : ");
        int row = obj1.nextInt();
        for (int i = 1; i <= row - 1; i++) {
            for (int j = 1; j <= row - i; j++) {
                System.out.print(" ");   // For space
            }
            for (int k = 1; k <= 2 * i - 1; k++) {
                System.out.print("*");  // for star

            }
            System.out.println();
        }
        for (int i = 1; i <= row; i++) {
            for (int j = 1; j <= i - 1; j++) {
                System.out.print(" ");   // For space
            }
            for (int k = 1; k <= 2 * (row - i) + 1; k++) {
                System.out.print("*");    // for star
            }
            System.out.println();

        }
        obj1.close();
    }
}
